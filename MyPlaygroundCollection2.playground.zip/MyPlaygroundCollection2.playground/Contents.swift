import UIKit

var backtoschoollist: [String] = ["pants" , "shoes", "shirts", "underwear"]
print("The back to school list contains \(backtoschoollist.count)items.")

backtoschoollist.append("Belts")
backtoschoollist += ["backpack"]

backtoschoollist.sort()
